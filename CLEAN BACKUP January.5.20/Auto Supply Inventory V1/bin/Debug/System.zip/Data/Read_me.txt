############     TO FORMAT THE SYSTEM   ###########

---------------------- FULLY CLOSE THE SYSTEM FIRST BY QUITING THE SYSTEM-------------------------

*JUST COPY AND PASTE THESE THREE FILES 
autosupply.mdb to the System Directory or Folder 

DeducLogfiles and DeliveryLogs to Documents Folder

And That's it! you now successfully formatted the System....